package com.codeshare.photomotion.callback;

import android.graphics.Bitmap;
import java.util.List;

public interface OnBitmapListCreated {
    void onBitmapRecived(List<Bitmap> list);
}
