package com.codeshare.photomotion.callback;

import com.codeshare.photomotion.model.EffectData;

public interface OnClickListner {
    void onClick(EffectData effectData, int i);
}
