package com.codeshare.photomotion.callback;

public interface OnProgressReceiver {
    void onImageProgressFrameUpdate(float f);
}
