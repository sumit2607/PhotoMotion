package com.codeshare.photomotion.callback;

import com.codeshare.photomotion.model.StickerData;

public interface OnStickerClickListner {
    void onClick(StickerData stickerData, int i);
}
